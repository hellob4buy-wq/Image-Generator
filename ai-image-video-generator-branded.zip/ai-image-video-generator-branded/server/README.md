# ArtForge Server — Deploy (Fly.io recommended)

## Environment
Copy `.env.example` -> `.env` and set `HUGGINGFACE_API_KEY` (get one from Hugging Face). You can set `HF_MODEL` to another HF model that supports image outputs (SDXL / SDXL-Turbo recommended).

## Local
npm i
node server.js

## Docker & Fly.io (quick)
1. Install Fly CLI and sign up.
2. Build and deploy:
   ```bash
   docker build -t artforge-server:latest .
   flyctl launch --name artforge-server --dockerfile ./Dockerfile
   flyctl deploy
   ```
Fly.io has a free tier suitable for low-volume usage. If Hugging Face quota is exceeded, the server automatically falls back to Pollinations. For higher reliability, upgrade HF or use dedicated inference endpoints. citeturn0search3turn0search4
